import React, { useState } from 'react';
import { Send, Bot, User, Clock, Search, ExternalLink, Database, Globe, Brain, Zap } from 'lucide-react';

interface Message {
  id: string;
  text: string;
  sender: 'user' | 'bot';
  timestamp: Date;
  sources?: Source[];
  dataSource?: 'internal' | 'external' | 'mixed';
  confidence?: number;
  reasoning?: string;
}

interface Source {
  title: string;
  url: string;
  domain: string;
  snippet?: string;
  type: 'internal' | 'external';
}

interface AIResponse {
  answer: string;
  confidence: number;
  reasoning: string;
  sources: Source[];
  dataSource: 'internal' | 'external' | 'mixed';
}

const ChatBot: React.FC = () => {
  const [messages, setMessages] = useState<Message[]>([
    {
      id: '1',
      text: 'Bonjour ! Je suis votre assistant comptable IA intelligent. Je peux analyser vos données financières, répondre aux questions fiscales marocaines, et vous fournir des conseils personnalisés. Comment puis-je vous aider aujourd\'hui ?',
      sender: 'bot',
      timestamp: new Date(),
      dataSource: 'internal',
      confidence: 1.0
    }
  ]);
  const [inputValue, setInputValue] = useState('');
  const [isLoading, setIsLoading] = useState(false);

  // Whitelisted domains for external searches
  const whitelistedDomains = [
    'taxe.gov.ma',
    'cnss.ma',
    'LegiMaroc.ma',
    'finances.gov.ma',
    'ompic.ma',
    'douane.gov.ma',
    'bkam.ma'
  ];

  const quickQuestions = [
    'Analysez ma situation financière actuelle',
    'Quelles sont mes obligations fiscales ce mois ?',
    'Comment optimiser mes charges ?',
    'Prévisions de trésorerie pour le trimestre',
    'Conseils pour réduire mes impôts',
    'Nouveautés fiscales Maroc 2024',
    'Calcul automatique TVA',
    'Stratégies d\'investissement recommandées'
  ];

  // Enhanced internal accounting data with more context
  const internalData = {
    company: {
      name: 'Smith & Associates Ltd',
      sector: 'Services professionnels',
      employees: 12,
      yearFounded: 2018
    },
    financial: {
      turnover: {
        monthly: 124590,
        yearly: 1245900,
        growth: 12.5,
        trend: 'positive',
        seasonality: 'Q4 peak'
      },
      expenses: {
        total: 89360,
        breakdown: [
          { category: 'Coûts du personnel', amount: 28500, percentage: 31.9 },
          { category: 'Loyer bureau', amount: 8200, percentage: 9.2 },
          { category: 'Services professionnels', amount: 4800, percentage: 5.4 },
          { category: 'Marketing', amount: 3200, percentage: 3.6 }
        ]
      },
      profitability: {
        netMargin: 36.3,
        grossMargin: 45.2,
        monthlyProfit: 45230,
        yearlyProjection: 542760
      },
      cashFlow: {
        current: 67450,
        projected30Days: 89200,
        projected90Days: 156800
      }
    },
    tax: {
      vatFiling: {
        nextDue: '2024-12-15',
        daysRemaining: 12,
        estimatedPayment: 18750,
        regime: 'mensuel'
      },
      corporateTax: {
        nextPayment: '2024-12-31',
        estimatedAmount: 45600,
        rate: 28
      }
    },
    operations: {
      pendingInvoices: {
        count: 23,
        total: 67450,
        overdue: { count: 5, total: 18200, avgDays: 45 }
      },
      bankAccounts: [
        { name: 'Compte principal', balance: 89450 },
        { name: 'Compte épargne', balance: 156000 }
      ]
    }
  };

  // Advanced AI knowledge base with contextual understanding
  const aiKnowledgeBase = {
    fiscal: {
      'tva': {
        rates: { normal: 20, reduced: [14, 10, 7] },
        thresholds: { monthly: 2000000, quarterly: 2000000 },
        deadlines: 'fin du mois suivant',
        penalties: 'calculées selon retard et montant dû'
      },
      'is': {
        rates: [
          { min: 0, max: 300000, rate: 10 },
          { min: 300001, max: 1000000, rate: 20 },
          { min: 1000001, max: Infinity, rate: 28 }
        ],
        payments: 'acomptes trimestriels 25%'
      },
      'cnss': {
        rate: 21.09,
        deadline: '10 du mois suivant',
        distribution: 'employeur majorité'
      }
    },
    business: {
      optimization: {
        expenses: [
          'Négocier contrats fournisseurs',
          'Optimiser charges sociales',
          'Déductions fiscales maximales',
          'Amortissements stratégiques'
        ],
        cashflow: [
          'Facturation anticipée',
          'Relance clients systématique',
          'Négociation délais fournisseurs',
          'Planification trésorerie'
        ]
      }
    }
  };

  // Advanced AI processing function
  const processWithAI = async (query: string): Promise<AIResponse> => {
    const lowerQuery = query.toLowerCase();
    
    // Intent recognition
    const intents = {
      financial_analysis: ['analys', 'situation', 'financ', 'bilan', 'performance'],
      tax_advice: ['fiscal', 'impôt', 'tva', 'cnss', 'déclaration'],
      optimization: ['optimis', 'réduire', 'économ', 'améliorer', 'conseil'],
      forecasting: ['prévision', 'projection', 'futur', 'tendance'],
      compliance: ['obligation', 'échéance', 'délai', 'conformité']
    };

    let detectedIntent = 'general';
    let intentScore = 0;

    for (const [intent, keywords] of Object.entries(intents)) {
      const score = keywords.reduce((acc, keyword) => 
        acc + (lowerQuery.includes(keyword) ? 1 : 0), 0
      );
      if (score > intentScore) {
        intentScore = score;
        detectedIntent = intent;
      }
    }

    // Generate contextual response based on intent
    switch (detectedIntent) {
      case 'financial_analysis':
        return generateFinancialAnalysis(query);
      case 'tax_advice':
        return generateTaxAdvice(query);
      case 'optimization':
        return generateOptimizationAdvice(query);
      case 'forecasting':
        return generateForecasting(query);
      case 'compliance':
        return generateComplianceAdvice(query);
      default:
        return generateGeneralResponse(query);
    }
  };

  const generateFinancialAnalysis = (query: string): AIResponse => {
    const data = internalData.financial;
    const analysis = `
**Analyse de votre situation financière :**

📊 **Performance actuelle :**
- Chiffre d'affaires mensuel : ${data.turnover.monthly.toLocaleString()} MAD (+${data.turnover.growth}%)
- Marge nette : ${data.profitability.netMargin}% (excellente pour votre secteur)
- Bénéfice mensuel : ${data.profitability.monthlyProfit.toLocaleString()} MAD

💰 **Trésorerie :**
- Position actuelle : ${data.cashFlow.current.toLocaleString()} MAD
- Projection 30 jours : ${data.cashFlow.projected30Days.toLocaleString()} MAD

⚠️ **Points d'attention :**
- ${internalData.operations.pendingInvoices.overdue.count} factures en retard (${internalData.operations.pendingInvoices.overdue.total.toLocaleString()} MAD)
- Délai moyen de paiement : ${internalData.operations.pendingInvoices.overdue.avgDays} jours

🎯 **Recommandations :**
1. Améliorer le recouvrement des créances
2. Maintenir la croissance actuelle
3. Optimiser la structure des coûts
    `;

    return {
      answer: analysis,
      confidence: 0.95,
      reasoning: 'Analyse basée sur vos données financières réelles avec calculs automatiques',
      sources: [
        {
          title: 'Tableau de bord financier',
          url: '/dashboard',
          domain: 'internal',
          type: 'internal'
        }
      ],
      dataSource: 'internal'
    };
  };

  const generateTaxAdvice = (query: string): AIResponse => {
    const lowerQuery = query.toLowerCase();
    
    if (lowerQuery.includes('tva')) {
      const vatData = internalData.tax.vatFiling;
      const advice = `
**Conseil TVA personnalisé :**

📅 **Votre situation :**
- Prochaine déclaration : ${vatData.nextDue} (dans ${vatData.daysRemaining} jours)
- Montant estimé : ${vatData.estimatedPayment.toLocaleString()} MAD
- Régime : ${vatData.regime} (CA > 2M MAD)

📋 **Taux TVA Maroc 2024 :**
- Taux normal : 20%
- Taux réduits : 14%, 10%, 7%

✅ **Actions recommandées :**
1. Préparer la déclaration maintenant
2. Vérifier les déductions possibles
3. Planifier la trésorerie pour le paiement

⚖️ **Réglementation :**
Selon taxe.gov.ma, les déclarations doivent être déposées avant la fin du mois suivant.
      `;

      return {
        answer: advice,
        confidence: 0.92,
        reasoning: 'Conseil personnalisé basé sur votre régime TVA et échéances',
        sources: [
          {
            title: 'Vos échéances TVA',
            url: '/transactions?filter=vat',
            domain: 'internal',
            type: 'internal'
          },
          {
            title: 'Réglementation TVA Maroc',
            url: 'https://taxe.gov.ma/wps/portal/tva',
            domain: 'taxe.gov.ma',
            type: 'external'
          }
        ],
        dataSource: 'mixed'
      };
    }

    if (lowerQuery.includes('impôt') || lowerQuery.includes('is')) {
      const profit = internalData.financial.profitability.yearlyProjection;
      let rate = 10;
      if (profit > 1000000) rate = 28;
      else if (profit > 300000) rate = 20;

      const advice = `
**Conseil Impôt sur les Sociétés :**

💼 **Votre situation :**
- Bénéfice projeté : ${profit.toLocaleString()} MAD
- Taux applicable : ${rate}%
- IS estimé : ${Math.round(profit * rate / 100).toLocaleString()} MAD

📊 **Barème IS Maroc 2024 :**
- 0 à 300K MAD : 10%
- 300K à 1M MAD : 20%
- Plus de 1M MAD : 28%

💡 **Optimisations possibles :**
1. Amortissements accélérés
2. Provisions déductibles
3. Investissements éligibles
4. Charges déductibles maximales
      `;

      return {
        answer: advice,
        confidence: 0.89,
        reasoning: 'Calcul automatique basé sur vos bénéfices projetés',
        sources: [
          {
            title: 'Calcul IS personnalisé',
            url: '/dashboard',
            domain: 'internal',
            type: 'internal'
          },
          {
            title: 'Barème IS Maroc',
            url: 'https://taxe.gov.ma/wps/portal/is',
            domain: 'taxe.gov.ma',
            type: 'external'
          }
        ],
        dataSource: 'mixed'
      };
    }

    return generateGeneralResponse(query);
  };

  const generateOptimizationAdvice = (query: string): AIResponse => {
    const expenses = internalData.financial.expenses;
    const advice = `
**Stratégies d'optimisation personnalisées :**

💰 **Analyse de vos charges (${expenses.total.toLocaleString()} MAD/mois) :**
${expenses.breakdown.map(exp => 
  `- ${exp.category} : ${exp.amount.toLocaleString()} MAD (${exp.percentage}%)`
).join('\n')}

🎯 **Recommandations prioritaires :**

1. **Optimisation fiscale :**
   - Maximiser déductions TVA
   - Amortissements stratégiques
   - Provisions pour risques

2. **Gestion des coûts :**
   - Renégocier contrats fournisseurs
   - Optimiser charges sociales
   - Digitaliser processus

3. **Amélioration trésorerie :**
   - Facturation anticipée
   - Relance automatisée
   - Escomptes fournisseurs

💡 **Impact estimé :** Économies potentielles de 8-12% sur vos charges.
    `;

    return {
      answer: advice,
      confidence: 0.87,
      reasoning: 'Analyse de vos charges réelles avec recommandations sectorielles',
      sources: [
        {
          title: 'Analyse des charges',
          url: '/transactions?type=expense',
          domain: 'internal',
          type: 'internal'
        }
      ],
      dataSource: 'internal'
    };
  };

  const generateForecasting = (query: string): AIResponse => {
    const data = internalData.financial;
    const forecast = `
**Prévisions financières intelligentes :**

📈 **Tendances détectées :**
- Croissance : +${data.turnover.growth}% (${data.turnover.trend})
- Saisonnalité : ${data.turnover.seasonality}
- Marge stable à ${data.profitability.netMargin}%

🔮 **Projections Q1 2025 :**
- CA estimé : ${Math.round(data.turnover.monthly * 3 * 1.125).toLocaleString()} MAD
- Bénéfice projeté : ${Math.round(data.profitability.monthlyProfit * 3 * 1.1).toLocaleString()} MAD
- Trésorerie fin Q1 : ${data.cashFlow.projected90Days.toLocaleString()} MAD

⚠️ **Risques identifiés :**
- Créances clients : ${internalData.operations.pendingInvoices.overdue.total.toLocaleString()} MAD à risque
- Saisonnalité Q1 : baisse habituelle 15-20%

🎯 **Actions préventives :**
1. Constituer réserve trésorerie
2. Intensifier recouvrement
3. Diversifier sources revenus
    `;

    return {
      answer: forecast,
      confidence: 0.83,
      reasoning: 'Modèle prédictif basé sur historique et tendances sectorielles',
      sources: [
        {
          title: 'Modèle de prévision',
          url: '/dashboard',
          domain: 'internal',
          type: 'internal'
        }
      ],
      dataSource: 'internal'
    };
  };

  const generateComplianceAdvice = (query: string): AIResponse => {
    const advice = `
**Calendrier des obligations fiscales :**

📅 **Échéances imminentes :**
- TVA : ${internalData.tax.vatFiling.nextDue} (${internalData.tax.vatFiling.daysRemaining} jours)
- IS acompte : ${internalData.tax.corporateTax.nextPayment}
- CNSS : 10 janvier 2025

✅ **Checklist conformité :**
1. ✓ Déclarations TVA à jour
2. ⚠️ Relance factures en retard
3. ✓ Cotisations sociales payées
4. ⚠️ Préparer bilan annuel

📋 **Documents requis :**
- Factures clients/fournisseurs
- Relevés bancaires
- Bulletins de paie
- Justificatifs charges

🔔 **Alertes automatiques configurées** pour toutes vos échéances.
    `;

    return {
      answer: advice,
      confidence: 0.94,
      reasoning: 'Calendrier personnalisé basé sur votre situation réelle',
      sources: [
        {
          title: 'Calendrier fiscal personnalisé',
          url: '/dashboard',
          domain: 'internal',
          type: 'internal'
        },
        {
          title: 'Obligations fiscales Maroc',
          url: 'https://taxe.gov.ma',
          domain: 'taxe.gov.ma',
          type: 'external'
        }
      ],
      dataSource: 'mixed'
    };
  };

  const generateGeneralResponse = (query: string): AIResponse => {
    return {
      answer: `Je comprends votre question sur "${query}". En tant qu'IA comptable spécialisée, je peux vous aider avec :

🧠 **Analyses intelligentes :**
- Diagnostic financier automatique
- Optimisations personnalisées
- Prévisions basées sur vos données

📊 **Données en temps réel :**
- Métriques financières actualisées
- Alertes proactives
- Recommandations contextuelles

🇲🇦 **Expertise fiscale Maroc :**
- Réglementation à jour
- Calculs automatiques
- Conseils conformité

Pourriez-vous préciser votre besoin pour une réponse plus ciblée ?`,
      confidence: 0.75,
      reasoning: 'Réponse générale avec orientation vers capacités spécialisées',
      sources: [
        {
          title: 'Assistant IA comptable',
          url: '/chat',
          domain: 'internal',
          type: 'internal'
        }
      ],
      dataSource: 'internal'
    };
  };

  const handleSendMessage = async (text: string) => {
    if (!text.trim()) return;

    const userMessage: Message = {
      id: Date.now().toString(),
      text,
      sender: 'user',
      timestamp: new Date()
    };

    setMessages(prev => [...prev, userMessage]);
    setInputValue('');
    setIsLoading(true);

    try {
      // Simulate AI processing time
      await new Promise(resolve => setTimeout(resolve, 1500 + Math.random() * 2000));
      
      const aiResponse = await processWithAI(text);
      
      const botMessage: Message = {
        id: (Date.now() + 1).toString(),
        text: aiResponse.answer,
        sender: 'bot',
        timestamp: new Date(),
        sources: aiResponse.sources,
        dataSource: aiResponse.dataSource,
        confidence: aiResponse.confidence,
        reasoning: aiResponse.reasoning
      };

      setMessages(prev => [...prev, botMessage]);
    } catch (error) {
      const errorMessage: Message = {
        id: (Date.now() + 1).toString(),
        text: 'Désolé, je rencontre une difficulté technique. Veuillez réessayer dans un moment.',
        sender: 'bot',
        timestamp: new Date(),
        dataSource: 'internal',
        confidence: 0.0
      };
      setMessages(prev => [...prev, errorMessage]);
    } finally {
      setIsLoading(false);
    }
  };

  const handleQuickQuestion = (question: string) => {
    handleSendMessage(question);
  };

  const getDataSourceIcon = (dataSource?: string) => {
    switch (dataSource) {
      case 'internal':
        return <Database className="w-4 h-4 text-blue-500" />;
      case 'external':
        return <Globe className="w-4 h-4 text-green-500" />;
      case 'mixed':
        return <Search className="w-4 h-4 text-purple-500" />;
      default:
        return <Brain className="w-4 h-4 text-indigo-500" />;
    }
  };

  const getDataSourceLabel = (dataSource?: string) => {
    switch (dataSource) {
      case 'internal':
        return 'Données internes';
      case 'external':
        return 'Sources externes';
      case 'mixed':
        return 'Sources mixtes';
      default:
        return 'IA';
    }
  };

  const getConfidenceColor = (confidence?: number) => {
    if (!confidence) return 'text-gray-500';
    if (confidence >= 0.9) return 'text-green-600';
    if (confidence >= 0.7) return 'text-yellow-600';
    return 'text-red-600';
  };

  return (
    <div className="flex flex-col h-[calc(100vh-200px)] bg-white rounded-lg shadow-sm border border-gray-200">
      <div className="flex items-center justify-between p-4 border-b border-gray-200">
        <div className="flex items-center space-x-3">
          <div className="w-10 h-10 bg-gradient-to-br from-indigo-500 to-purple-600 rounded-full flex items-center justify-center">
            <Brain className="w-6 h-6 text-white" />
          </div>
          <div>
            <h3 className="text-lg font-semibold text-gray-900">Assistant IA Intelligent</h3>
            <p className="text-sm text-gray-500">Analyse avancée + sources marocaines fiables</p>
          </div>
        </div>
        <div className="flex items-center space-x-2 text-xs text-gray-500">
          <Zap className="w-4 h-4 text-yellow-500" />
          <span>IA</span>
          <Database className="w-4 h-4 text-blue-500" />
          <span>Interne</span>
          <Globe className="w-4 h-4 text-green-500" />
          <span>Externe</span>
        </div>
      </div>

      <div className="flex-1 overflow-y-auto p-4 space-y-4">
        {messages.map((message) => (
          <div
            key={message.id}
            className={`flex ${message.sender === 'user' ? 'justify-end' : 'justify-start'}`}
          >
            <div
              className={`max-w-xs lg:max-w-md px-4 py-3 rounded-lg ${
                message.sender === 'user'
                  ? 'bg-indigo-600 text-white'
                  : 'bg-gray-100 text-gray-900'
              }`}
            >
              <div className="flex items-center space-x-2 mb-1">
                {message.sender === 'user' ? (
                  <User className="w-4 h-4" />
                ) : (
                  getDataSourceIcon(message.dataSource)
                )}
                <span className="text-xs opacity-75">
                  {message.timestamp.toLocaleTimeString()}
                </span>
                {message.sender === 'bot' && message.dataSource && (
                  <span className="text-xs opacity-75">
                    • {getDataSourceLabel(message.dataSource)}
                  </span>
                )}
                {message.confidence && (
                  <span className={`text-xs ${getConfidenceColor(message.confidence)}`}>
                    • {Math.round(message.confidence * 100)}%
                  </span>
                )}
              </div>
              <div className="text-sm whitespace-pre-line">{message.text}</div>
              
              {/* AI Reasoning */}
              {message.reasoning && (
                <div className="mt-2 pt-2 border-t border-gray-200">
                  <p className="text-xs opacity-75 italic">💡 {message.reasoning}</p>
                </div>
              )}
              
              {/* Sources */}
              {message.sources && message.sources.length > 0 && (
                <div className="mt-3 pt-2 border-t border-gray-200">
                  <p className="text-xs font-medium mb-2 opacity-75">Sources :</p>
                  <div className="space-y-1">
                    {message.sources.map((source, index) => (
                      <div key={index} className="flex items-center space-x-2">
                        {source.type === 'internal' ? (
                          <Database className="w-3 h-3 text-blue-500" />
                        ) : (
                          <ExternalLink className="w-3 h-3 text-green-500" />
                        )}
                        <a
                          href={source.url}
                          target={source.type === 'external' ? '_blank' : '_self'}
                          rel={source.type === 'external' ? 'noopener noreferrer' : ''}
                          className="text-xs underline opacity-75 hover:opacity-100"
                        >
                          {source.title}
                        </a>
                        <span className="text-xs opacity-50">({source.domain})</span>
                      </div>
                    ))}
                  </div>
                </div>
              )}
            </div>
          </div>
        ))}
        
        {isLoading && (
          <div className="flex justify-start">
            <div className="bg-gray-100 text-gray-900 max-w-xs lg:max-w-md px-4 py-3 rounded-lg">
              <div className="flex items-center space-x-2">
                <div className="flex space-x-1">
                  <div className="w-2 h-2 bg-indigo-400 rounded-full animate-bounce"></div>
                  <div className="w-2 h-2 bg-indigo-400 rounded-full animate-bounce" style={{ animationDelay: '0.1s' }}></div>
                  <div className="w-2 h-2 bg-indigo-400 rounded-full animate-bounce" style={{ animationDelay: '0.2s' }}></div>
                </div>
                <span className="text-xs text-gray-500">IA en cours d'analyse...</span>
              </div>
            </div>
          </div>
        )}
      </div>

      <div className="p-4 border-t border-gray-200">
        <div className="flex flex-wrap gap-2 mb-3">
          {quickQuestions.map((question, index) => (
            <button
              key={index}
              onClick={() => handleQuickQuestion(question)}
              className="px-3 py-1 text-sm bg-gradient-to-r from-indigo-50 to-purple-50 hover:from-indigo-100 hover:to-purple-100 rounded-full transition-colors flex items-center space-x-1 border border-indigo-200"
            >
              <Brain className="w-3 h-3 text-indigo-500" />
              <span>{question}</span>
            </button>
          ))}
        </div>
        
        <div className="flex space-x-2">
          <input
            type="text"
            value={inputValue}
            onChange={(e) => setInputValue(e.target.value)}
            onKeyPress={(e) => e.key === 'Enter' && handleSendMessage(inputValue)}
            placeholder="Posez une question intelligente sur vos finances..."
            className="flex-1 px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-indigo-500 focus:border-transparent"
            disabled={isLoading}
          />
          <button
            onClick={() => handleSendMessage(inputValue)}
            disabled={isLoading || !inputValue.trim()}
            className="px-4 py-2 bg-gradient-to-r from-indigo-600 to-purple-600 text-white rounded-lg hover:from-indigo-700 hover:to-purple-700 disabled:opacity-50 disabled:cursor-not-allowed transition-colors"
          >
            <Send className="w-4 h-4" />
          </button>
        </div>
        
        <div className="mt-2 text-xs text-gray-500 text-center">
          🧠 IA avancée • 📊 Analyse de données • 🇲🇦 Expertise fiscale Maroc • 🔍 Sources fiables
        </div>
      </div>
    </div>
  );
};

export default ChatBot;