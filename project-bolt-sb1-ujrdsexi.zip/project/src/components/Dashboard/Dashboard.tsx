import React from 'react';
import { DollarSign, TrendingUp, Users, FileText, AlertCircle } from 'lucide-react';
import MetricCard from './MetricCard';
import RevenueChart from './RevenueChart';

const Dashboard: React.FC = () => {
  const metrics = [
    {
      title: 'Total Revenue',
      value: '£124,590',
      change: 12.5,
      period: 'vs last month',
      icon: <DollarSign className="w-6 h-6 text-white" />,
      color: 'bg-gradient-to-br from-emerald-500 to-teal-600'
    },
    {
      title: 'Net Profit',
      value: '£45,230',
      change: 8.2,
      period: 'vs last month',
      icon: <TrendingUp className="w-6 h-6 text-white" />,
      color: 'bg-gradient-to-br from-blue-500 to-indigo-600'
    },
    {
      title: 'Active Clients',
      value: '1,423',
      change: 5.1,
      period: 'vs last month',
      icon: <Users className="w-6 h-6 text-white" />,
      color: 'bg-gradient-to-br from-purple-500 to-pink-600'
    },
    {
      title: 'Documents Processed',
      value: '892',
      change: 15.3,
      period: 'vs last month',
      icon: <FileText className="w-6 h-6 text-white" />,
      color: 'bg-gradient-to-br from-orange-500 to-red-600'
    }
  ];

  const recentAlerts = [
    { id: 1, message: 'VAT payment due in 5 days', type: 'warning' },
    { id: 2, message: 'Monthly bank statements ready for review', type: 'info' },
    { id: 3, message: 'New expense claim requires approval', type: 'warning' },
  ];

  return (
    <div className="space-y-6">
      <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-4 gap-6">
        {metrics.map((metric, index) => (
          <MetricCard key={index} {...metric} />
        ))}
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <div className="lg:col-span-2">
          <RevenueChart />
        </div>
        
        <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-6">
          <h3 className="text-lg font-semibold text-gray-900 mb-4">Recent Alerts</h3>
          <div className="space-y-3">
            {recentAlerts.map((alert) => (
              <div key={alert.id} className="flex items-start space-x-3 p-3 bg-yellow-50 rounded-lg">
                <AlertCircle className="w-5 h-5 text-yellow-600 mt-0.5" />
                <p className="text-sm text-gray-700">{alert.message}</p>
              </div>
            ))}
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-6">
          <h3 className="text-lg font-semibold text-gray-900 mb-4">Recent Transactions</h3>
          <div className="space-y-3">
            {[1, 2, 3, 4].map((i) => (
              <div key={i} className="flex items-center justify-between py-3 border-b border-gray-100 last:border-b-0">
                <div className="flex items-center space-x-3">
                  <div className="w-10 h-10 bg-gray-100 rounded-full flex items-center justify-center">
                    <DollarSign className="w-5 h-5 text-gray-600" />
                  </div>
                  <div>
                    <p className="text-sm font-medium text-gray-900">Payment from Client #{i}</p>
                    <p className="text-xs text-gray-500">2 hours ago</p>
                  </div>
                </div>
                <span className="text-sm font-medium text-emerald-600">+£{(i * 1250).toLocaleString()}</span>
              </div>
            ))}
          </div>
        </div>

        <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-6">
          <h3 className="text-lg font-semibold text-gray-900 mb-4">Upcoming Deadlines</h3>
          <div className="space-y-3">
            {[
              { task: 'VAT Return Filing', date: 'Dec 15, 2024' },
              { task: 'Corporation Tax', date: 'Dec 31, 2024' },
              { task: 'Payroll Submission', date: 'Jan 19, 2025' },
              { task: 'Annual Returns', date: 'Feb 28, 2025' }
            ].map((item, i) => (
              <div key={i} className="flex items-center justify-between py-3 border-b border-gray-100 last:border-b-0">
                <div>
                  <p className="text-sm font-medium text-gray-900">{item.task}</p>
                  <p className="text-xs text-gray-500">{item.date}</p>
                </div>
                <span className={`text-xs px-2 py-1 rounded-full ${
                  i === 0 ? 'bg-red-100 text-red-800' : 'bg-yellow-100 text-yellow-800'
                }`}>
                  {i === 0 ? 'Urgent' : 'Upcoming'}
                </span>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};

export default Dashboard;