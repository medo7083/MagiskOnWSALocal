import React, { useState } from 'react';
import { Users, FileText, CheckCircle, Clock, Eye, Edit, Download, Filter, Upload, DollarSign, Building, Hash } from 'lucide-react';

interface ClientUpload {
  id: string;
  clientName: string;
  clientEmail: string;
  documentType: 'bank-statement' | 'invoice';
  fileName: string;
  uploadDate: string;
  status: 'pending' | 'processing' | 'validated' | 'completed';
  extractedData?: any;
  confidence?: number;
}

interface ChartOfAccount {
  code: string;
  name: string;
  type: 'asset' | 'liability' | 'equity' | 'revenue' | 'expense';
  category: string;
}

const AdminDashboard: React.FC = () => {
  const [activeTab, setActiveTab] = useState('overview');
  const [filterStatus, setFilterStatus] = useState('all');
  const [filterType, setFilterType] = useState('all');
  const [selectedUpload, setSelectedUpload] = useState<ClientUpload | null>(null);
  const [chartOfAccounts, setChartOfAccounts] = useState<ChartOfAccount[]>([
    { code: '1000', name: 'Cash and Bank', type: 'asset', category: 'Current Assets' },
    { code: '1200', name: 'Equipment', type: 'asset', category: 'Fixed Assets' },
    { code: '5000', name: 'Office Expenses', type: 'expense', category: 'Operating Expenses' },
    { code: '5100', name: 'Professional Fees', type: 'expense', category: 'Operating Expenses' },
    { code: '5200', name: 'Marketing Expenses', type: 'expense', category: 'Operating Expenses' },
    { code: '4000', name: 'Sales Revenue', type: 'revenue', category: 'Operating Revenue' }
  ]);

  const mockUploads: ClientUpload[] = [
    {
      id: '1',
      clientName: 'John Smith',
      clientEmail: 'john@example.com',
      documentType: 'invoice',
      fileName: 'Invoice_ABC_Corp_2024.pdf',
      uploadDate: '2024-01-15T10:30:00Z',
      status: 'pending',
      confidence: 0.94,
      extractedData: {
        invoiceNumber: 'INV-2024-001',
        supplierName: 'ABC Corp',
        netAmount: 1250.00,
        vatAmount: 250.00,
        totalAmount: 1500.00,
        accountingNature: 'Office Supplies',
        suggestedLedgerAccount: '5000 - Office Expenses'
      }
    },
    {
      id: '2',
      clientName: 'Sarah Johnson',
      clientEmail: 'sarah@example.com',
      documentType: 'bank-statement',
      fileName: 'Bank_Statement_Jan_2024.pdf',
      uploadDate: '2024-01-14T14:20:00Z',
      status: 'processing',
      extractedData: {
        accountNumber: '****1234',
        startingBalance: 15420.50,
        endingBalance: 18750.25,
        transactionCount: 23,
        taggedTransactions: 18
      }
    },
    {
      id: '3',
      clientName: 'Mike Wilson',
      clientEmail: 'mike@example.com',
      documentType: 'invoice',
      fileName: 'Purchase_Invoice_XYZ.pdf',
      uploadDate: '2024-01-13T09:15:00Z',
      status: 'validated',
      confidence: 0.89,
      extractedData: {
        invoiceNumber: 'PI-2024-003',
        supplierName: 'XYZ Supplies',
        netAmount: 708.33,
        vatAmount: 141.67,
        totalAmount: 850.00,
        accountingNature: 'Professional Services',
        suggestedLedgerAccount: '5100 - Professional Fees'
      }
    }
  ];

  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'pending':
        return <Clock className="w-4 h-4 text-yellow-500" />;
      case 'processing':
        return <div className="w-4 h-4 border-2 border-blue-500 border-t-transparent rounded-full animate-spin" />;
      case 'validated':
        return <CheckCircle className="w-4 h-4 text-green-500" />;
      case 'completed':
        return <CheckCircle className="w-4 h-4 text-gray-500" />;
      default:
        return <Clock className="w-4 h-4 text-gray-500" />;
    }
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'pending':
        return 'bg-yellow-100 text-yellow-800';
      case 'processing':
        return 'bg-blue-100 text-blue-800';
      case 'validated':
        return 'bg-green-100 text-green-800';
      case 'completed':
        return 'bg-gray-100 text-gray-800';
      default:
        return 'bg-gray-100 text-gray-800';
    }
  };

  const getConfidenceColor = (confidence?: number) => {
    if (!confidence) return 'text-gray-500';
    if (confidence >= 0.9) return 'text-green-600';
    if (confidence >= 0.7) return 'text-yellow-600';
    return 'text-red-600';
  };

  const filteredUploads = mockUploads.filter(upload => {
    const matchesStatus = filterStatus === 'all' || upload.status === filterStatus;
    const matchesType = filterType === 'all' || upload.documentType === filterType;
    return matchesStatus && matchesType;
  });

  const stats = {
    totalClients: 15,
    pendingReviews: mockUploads.filter(u => u.status === 'pending').length,
    processedToday: 8,
    totalUploads: mockUploads.length,
    avgConfidence: mockUploads.filter(u => u.confidence).reduce((acc, u) => acc + (u.confidence || 0), 0) / mockUploads.filter(u => u.confidence).length
  };

  const handleValidateUpload = (uploadId: string) => {
    // Simulate validation
    alert(`Upload ${uploadId} validated and ready for posting to accounting system.`);
  };

  const handlePostToAccounting = (uploadId: string) => {
    // Simulate posting to accounting system
    alert(`Upload ${uploadId} posted to accounting system successfully.`);
  };

  const handleChartUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      // Simulate chart of accounts upload
      alert('Chart of accounts uploaded successfully. AI will now use these accounts for better suggestions.');
    }
  };

  const renderOverview = () => (
    <div className="space-y-6">
      {/* Stats Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-6">
        <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-6">
          <div className="flex items-center">
            <div className="w-12 h-12 bg-blue-100 rounded-lg flex items-center justify-center">
              <Users className="w-6 h-6 text-blue-600" />
            </div>
            <div className="ml-4">
              <p className="text-sm font-medium text-gray-600">Total Clients</p>
              <p className="text-2xl font-bold text-gray-900">{stats.totalClients}</p>
            </div>
          </div>
        </div>

        <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-6">
          <div className="flex items-center">
            <div className="w-12 h-12 bg-yellow-100 rounded-lg flex items-center justify-center">
              <Clock className="w-6 h-6 text-yellow-600" />
            </div>
            <div className="ml-4">
              <p className="text-sm font-medium text-gray-600">Pending Reviews</p>
              <p className="text-2xl font-bold text-gray-900">{stats.pendingReviews}</p>
            </div>
          </div>
        </div>

        <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-6">
          <div className="flex items-center">
            <div className="w-12 h-12 bg-green-100 rounded-lg flex items-center justify-center">
              <CheckCircle className="w-6 h-6 text-green-600" />
            </div>
            <div className="ml-4">
              <p className="text-sm font-medium text-gray-600">Processed Today</p>
              <p className="text-2xl font-bold text-gray-900">{stats.processedToday}</p>
            </div>
          </div>
        </div>

        <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-6">
          <div className="flex items-center">
            <div className="w-12 h-12 bg-purple-100 rounded-lg flex items-center justify-center">
              <FileText className="w-6 h-6 text-purple-600" />
            </div>
            <div className="ml-4">
              <p className="text-sm font-medium text-gray-600">Total Uploads</p>
              <p className="text-2xl font-bold text-gray-900">{stats.totalUploads}</p>
            </div>
          </div>
        </div>

        <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-6">
          <div className="flex items-center">
            <div className="w-12 h-12 bg-indigo-100 rounded-lg flex items-center justify-center">
              <CheckCircle className="w-6 h-6 text-indigo-600" />
            </div>
            <div className="ml-4">
              <p className="text-sm font-medium text-gray-600">Avg AI Confidence</p>
              <p className="text-2xl font-bold text-gray-900">{Math.round(stats.avgConfidence * 100)}%</p>
            </div>
          </div>
        </div>
      </div>

      {/* Chart of Accounts Upload */}
      <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-6">
        <h3 className="text-lg font-semibold text-gray-900 mb-4">Chart of Accounts Management</h3>
        <div className="flex items-center justify-between">
          <div>
            <p className="text-gray-600 mb-2">Upload your chart of accounts to improve AI suggestions</p>
            <p className="text-sm text-gray-500">Supported formats: CSV, Excel</p>
          </div>
          <div>
            <input
              type="file"
              accept=".csv,.xls,.xlsx"
              onChange={handleChartUpload}
              className="hidden"
              id="chart-upload"
            />
            <label
              htmlFor="chart-upload"
              className="inline-flex items-center px-4 py-2 border border-transparent text-sm font-medium rounded-md text-white bg-indigo-600 hover:bg-indigo-700 cursor-pointer"
            >
              <Upload className="w-4 h-4 mr-2" />
              Upload Chart of Accounts
            </label>
          </div>
        </div>
        
        {/* Current Chart Preview */}
        <div className="mt-4">
          <h4 className="text-sm font-medium text-gray-700 mb-2">Current Chart of Accounts ({chartOfAccounts.length} accounts)</h4>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-2">
            {chartOfAccounts.slice(0, 6).map((account) => (
              <div key={account.code} className="text-xs bg-gray-50 rounded p-2">
                <span className="font-medium">{account.code}</span> - {account.name}
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Recent Activity */}
      <div className="bg-white rounded-lg shadow-sm border border-gray-200">
        <div className="p-6 border-b border-gray-200">
          <h3 className="text-lg font-semibold text-gray-900">Recent Activity</h3>
        </div>
        <div className="p-6">
          <div className="space-y-4">
            {mockUploads.slice(0, 5).map((upload) => (
              <div key={upload.id} className="flex items-center justify-between py-3 border-b border-gray-100 last:border-b-0">
                <div className="flex items-center space-x-3">
                  <div className="w-10 h-10 bg-gray-100 rounded-full flex items-center justify-center">
                    <FileText className="w-5 h-5 text-gray-600" />
                  </div>
                  <div>
                    <p className="text-sm font-medium text-gray-900">{upload.clientName}</p>
                    <p className="text-xs text-gray-500">
                      Uploaded {upload.documentType.replace('-', ' ')} • {new Date(upload.uploadDate).toLocaleDateString()}
                      {upload.confidence && (
                        <span className={`ml-2 ${getConfidenceColor(upload.confidence)}`}>
                          • {Math.round(upload.confidence * 100)}% confidence
                        </span>
                      )}
                    </p>
                  </div>
                </div>
                <div className="flex items-center space-x-2">
                  {getStatusIcon(upload.status)}
                  <span className={`inline-flex px-2 py-1 text-xs font-semibold rounded-full ${getStatusColor(upload.status)}`}>
                    {upload.status}
                  </span>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );

  const renderUploads = () => (
    <div className="space-y-6">
      {/* Filters */}
      <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-4">
        <div className="flex flex-col md:flex-row gap-4">
          <div className="flex items-center space-x-2">
            <Filter className="w-4 h-4 text-gray-400" />
            <span className="text-sm font-medium text-gray-700">Filters:</span>
          </div>
          <select
            value={filterStatus}
            onChange={(e) => setFilterStatus(e.target.value)}
            className="px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
          >
            <option value="all">All Statuses</option>
            <option value="pending">Pending</option>
            <option value="processing">Processing</option>
            <option value="validated">Validated</option>
            <option value="completed">Completed</option>
          </select>
          <select
            value={filterType}
            onChange={(e) => setFilterType(e.target.value)}
            className="px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
          >
            <option value="all">All Types</option>
            <option value="bank-statement">Bank Statements</option>
            <option value="invoice">Invoices</option>
          </select>
        </div>
      </div>

      {/* Uploads Table */}
      <div className="bg-white rounded-lg shadow-sm border border-gray-200">
        <div className="p-4 border-b border-gray-200">
          <h3 className="text-lg font-semibold text-gray-900">Client Uploads</h3>
        </div>
        <div className="overflow-x-auto">
          <table className="w-full">
            <thead className="bg-gray-50">
              <tr>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Client
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Document
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Type
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  AI Confidence
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Upload Date
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Status
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Actions
                </th>
              </tr>
            </thead>
            <tbody className="bg-white divide-y divide-gray-200">
              {filteredUploads.map((upload) => (
                <tr key={upload.id} className="hover:bg-gray-50">
                  <td className="px-6 py-4 whitespace-nowrap">
                    <div>
                      <div className="text-sm font-medium text-gray-900">{upload.clientName}</div>
                      <div className="text-sm text-gray-500">{upload.clientEmail}</div>
                    </div>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                    {upload.fileName}
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap">
                    <span className="inline-flex px-2 py-1 text-xs font-semibold rounded-full bg-blue-100 text-blue-800">
                      {upload.documentType.replace('-', ' ')}
                    </span>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap">
                    {upload.confidence ? (
                      <span className={`text-sm font-medium ${getConfidenceColor(upload.confidence)}`}>
                        {Math.round(upload.confidence * 100)}%
                      </span>
                    ) : (
                      <span className="text-sm text-gray-400">-</span>
                    )}
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                    {new Date(upload.uploadDate).toLocaleDateString()}
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap">
                    <div className="flex items-center space-x-2">
                      {getStatusIcon(upload.status)}
                      <span className={`inline-flex px-2 py-1 text-xs font-semibold rounded-full ${getStatusColor(upload.status)}`}>
                        {upload.status}
                      </span>
                    </div>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm font-medium">
                    <div className="flex items-center space-x-2">
                      <button 
                        onClick={() => setSelectedUpload(upload)}
                        className="text-blue-600 hover:text-blue-900"
                      >
                        <Eye className="w-4 h-4" />
                      </button>
                      {upload.status === 'pending' && (
                        <button 
                          onClick={() => handleValidateUpload(upload.id)}
                          className="text-green-600 hover:text-green-900"
                        >
                          <CheckCircle className="w-4 h-4" />
                        </button>
                      )}
                      {upload.status === 'validated' && (
                        <button 
                          onClick={() => handlePostToAccounting(upload.id)}
                          className="text-purple-600 hover:text-purple-900"
                        >
                          <Upload className="w-4 h-4" />
                        </button>
                      )}
                      <button className="text-gray-600 hover:text-gray-900">
                        <Download className="w-4 h-4" />
                      </button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* Upload Details Modal */}
      {selectedUpload && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
          <div className="bg-white rounded-lg shadow-xl max-w-2xl w-full mx-4 max-h-96 overflow-y-auto">
            <div className="p-6 border-b border-gray-200">
              <div className="flex items-center justify-between">
                <h3 className="text-lg font-semibold text-gray-900">Upload Details</h3>
                <button 
                  onClick={() => setSelectedUpload(null)}
                  className="text-gray-400 hover:text-gray-600"
                >
                  <X className="w-6 h-6" />
                </button>
              </div>
            </div>
            
            <div className="p-6 space-y-4">
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm font-medium text-gray-700">Client</label>
                  <p className="text-sm text-gray-900">{selectedUpload.clientName}</p>
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700">Document Type</label>
                  <p className="text-sm text-gray-900">{selectedUpload.documentType}</p>
                </div>
              </div>

              {selectedUpload.extractedData && (
                <div>
                  <h4 className="text-sm font-medium text-gray-700 mb-2">Extracted Data</h4>
                  <div className="bg-gray-50 rounded-lg p-4 space-y-2">
                    {selectedUpload.documentType === 'invoice' ? (
                      <>
                        <div className="flex items-center space-x-2">
                          <Hash className="w-4 h-4 text-gray-400" />
                          <span className="text-sm">Invoice: {selectedUpload.extractedData.invoiceNumber}</span>
                        </div>
                        <div className="flex items-center space-x-2">
                          <Building className="w-4 h-4 text-gray-400" />
                          <span className="text-sm">Supplier: {selectedUpload.extractedData.supplierName}</span>
                        </div>
                        <div className="flex items-center space-x-2">
                          <DollarSign className="w-4 h-4 text-gray-400" />
                          <span className="text-sm">Total: £{selectedUpload.extractedData.totalAmount}</span>
                        </div>
                        <div className="text-sm">
                          <span className="font-medium">Suggested Account:</span> {selectedUpload.extractedData.suggestedLedgerAccount}
                        </div>
                      </>
                    ) : (
                      <>
                        <div className="text-sm">Account: {selectedUpload.extractedData.accountNumber}</div>
                        <div className="text-sm">Transactions: {selectedUpload.extractedData.transactionCount}</div>
                        <div className="text-sm">Tagged: {selectedUpload.extractedData.taggedTransactions}/{selectedUpload.extractedData.transactionCount}</div>
                        <div className="text-sm">
                          Balance: £{selectedUpload.extractedData.startingBalance} → £{selectedUpload.extractedData.endingBalance}
                        </div>
                      </>
                    )}
                  </div>
                </div>
              )}

              <div className="flex justify-end space-x-2">
                {selectedUpload.status === 'pending' && (
                  <button 
                    onClick={() => {
                      handleValidateUpload(selectedUpload.id);
                      setSelectedUpload(null);
                    }}
                    className="px-4 py-2 bg-green-600 text-white rounded-lg hover:bg-green-700"
                  >
                    Validate & Approve
                  </button>
                )}
                {selectedUpload.status === 'validated' && (
                  <button 
                    onClick={() => {
                      handlePostToAccounting(selectedUpload.id);
                      setSelectedUpload(null);
                    }}
                    className="px-4 py-2 bg-purple-600 text-white rounded-lg hover:bg-purple-700"
                  >
                    Post to Accounting
                  </button>
                )}
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );

  return (
    <div className="min-h-screen bg-gray-100">
      <div className="bg-white shadow-sm border-b border-gray-200">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center py-6">
            <div>
              <h1 className="text-2xl font-bold text-gray-900">Admin Dashboard</h1>
              <p className="text-gray-600">Manage client uploads, validate AI extractions, and post to accounting</p>
            </div>
          </div>
          
          <div className="flex space-x-8">
            <button
              onClick={() => setActiveTab('overview')}
              className={`py-4 px-1 border-b-2 font-medium text-sm ${
                activeTab === 'overview'
                  ? 'border-blue-500 text-blue-600'
                  : 'border-transparent text-gray-500 hover:text-gray-700'
              }`}
            >
              Overview
            </button>
            <button
              onClick={() => setActiveTab('uploads')}
              className={`py-4 px-1 border-b-2 font-medium text-sm ${
                activeTab === 'uploads'
                  ? 'border-blue-500 text-blue-600'
                  : 'border-transparent text-gray-500 hover:text-gray-700'
              }`}
            >
              Client Uploads
            </button>
          </div>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {activeTab === 'overview' ? renderOverview() : renderUploads()}
      </div>
    </div>
  );
};

export default AdminDashboard;