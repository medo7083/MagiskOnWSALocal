import React, { useState } from 'react';
import { FolderOpen, File, Download, Eye, Calendar, Search } from 'lucide-react';

interface Document {
  id: string;
  name: string;
  type: 'legal' | 'contract' | 'certificate' | 'report';
  category: string;
  uploadDate: string;
  size: string;
  expiryDate?: string;
}

const DocumentManager: React.FC = () => {
  const [searchTerm, setSearchTerm] = useState('');
  const [filterType, setFilterType] = useState('all');

  const documents: Document[] = [
    {
      id: '1',
      name: 'Company Registration Certificate',
      type: 'certificate',
      category: 'Corporate Documents',
      uploadDate: '2024-01-15',
      size: '2.4 MB',
      expiryDate: '2025-01-15'
    },
    {
      id: '2',
      name: 'Articles of Association',
      type: 'legal',
      category: 'Corporate Documents',
      uploadDate: '2024-01-10',
      size: '1.8 MB'
    },
    {
      id: '3',
      name: 'VAT Registration Certificate',
      type: 'certificate',
      category: 'Tax Documents',
      uploadDate: '2024-01-08',
      size: '1.2 MB',
      expiryDate: '2025-12-31'
    },
    {
      id: '4',
      name: 'Insurance Policy - Professional Indemnity',
      type: 'contract',
      category: 'Insurance',
      uploadDate: '2024-01-05',
      size: '3.1 MB',
      expiryDate: '2024-12-31'
    },
    {
      id: '5',
      name: 'Annual Return 2023',
      type: 'report',
      category: 'Regulatory Filings',
      uploadDate: '2024-01-03',
      size: '4.5 MB'
    }
  ];

  const getDocumentIcon = (type: string) => {
    const iconClass = "w-8 h-8";
    switch (type) {
      case 'legal':
        return <File className={`${iconClass} text-blue-500`} />;
      case 'contract':
        return <File className={`${iconClass} text-green-500`} />;
      case 'certificate':
        return <File className={`${iconClass} text-purple-500`} />;
      case 'report':
        return <File className={`${iconClass} text-orange-500`} />;
      default:
        return <File className={`${iconClass} text-gray-500`} />;
    }
  };

  const isExpiringSoon = (expiryDate?: string) => {
    if (!expiryDate) return false;
    const expiry = new Date(expiryDate);
    const today = new Date();
    const diffTime = expiry.getTime() - today.getTime();
    const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));
    return diffDays <= 30 && diffDays > 0;
  };

  const filteredDocuments = documents.filter(doc => {
    const matchesSearch = doc.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         doc.category.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesType = filterType === 'all' || doc.type === filterType;
    return matchesSearch && matchesType;
  });

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-4">
        <div className="flex flex-col md:flex-row gap-4">
          <div className="flex-1 relative">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4" />
            <input
              type="text"
              placeholder="Search documents..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="pl-10 w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
            />
          </div>
          <select
            value={filterType}
            onChange={(e) => setFilterType(e.target.value)}
            className="px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
          >
            <option value="all">All Types</option>
            <option value="legal">Legal Documents</option>
            <option value="contract">Contracts</option>
            <option value="certificate">Certificates</option>
            <option value="report">Reports</option>
          </select>
        </div>
      </div>

      {/* Categories */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        {[
          { name: 'Corporate Documents', count: 2, icon: FolderOpen, color: 'bg-blue-100 text-blue-800' },
          { name: 'Tax Documents', count: 1, icon: FolderOpen, color: 'bg-green-100 text-green-800' },
          { name: 'Insurance', count: 1, icon: FolderOpen, color: 'bg-purple-100 text-purple-800' },
          { name: 'Regulatory Filings', count: 1, icon: FolderOpen, color: 'bg-orange-100 text-orange-800' }
        ].map((category, index) => (
          <div key={index} className="bg-white rounded-lg shadow-sm border border-gray-200 p-4">
            <div className="flex items-center space-x-3">
              <div className={`w-12 h-12 rounded-lg flex items-center justify-center ${category.color}`}>
                <category.icon className="w-6 h-6" />
              </div>
              <div>
                <h3 className="font-medium text-gray-900">{category.name}</h3>
                <p className="text-sm text-gray-500">{category.count} documents</p>
              </div>
            </div>
          </div>
        ))}
      </div>

      {/* Documents List */}
      <div className="bg-white rounded-lg shadow-sm border border-gray-200">
        <div className="p-4 border-b border-gray-200">
          <h3 className="text-lg font-semibold text-gray-900">Documents</h3>
        </div>
        <div className="p-4">
          <div className="space-y-4">
            {filteredDocuments.map((document) => (
              <div key={document.id} className="flex items-center justify-between p-4 bg-gray-50 rounded-lg hover:bg-gray-100 transition-colors">
                <div className="flex items-center space-x-4">
                  {getDocumentIcon(document.type)}
                  <div className="flex-1 min-w-0">
                    <h4 className="text-sm font-medium text-gray-900 truncate">{document.name}</h4>
                    <div className="flex items-center space-x-4 mt-1">
                      <p className="text-sm text-gray-500">{document.category}</p>
                      <p className="text-sm text-gray-500">{document.size}</p>
                      <p className="text-sm text-gray-500">
                        Uploaded: {new Date(document.uploadDate).toLocaleDateString()}
                      </p>
                      {document.expiryDate && (
                        <div className="flex items-center space-x-1">
                          <Calendar className="w-4 h-4 text-gray-400" />
                          <p className={`text-sm ${isExpiringSoon(document.expiryDate) ? 'text-red-600' : 'text-gray-500'}`}>
                            Expires: {new Date(document.expiryDate).toLocaleDateString()}
                          </p>
                        </div>
                      )}
                    </div>
                  </div>
                </div>
                <div className="flex items-center space-x-2">
                  {isExpiringSoon(document.expiryDate) && (
                    <span className="inline-flex px-2 py-1 text-xs font-semibold rounded-full bg-red-100 text-red-800">
                      Expiring Soon
                    </span>
                  )}
                  <button className="p-2 text-gray-400 hover:text-gray-600">
                    <Eye className="w-4 h-4" />
                  </button>
                  <button className="p-2 text-gray-400 hover:text-gray-600">
                    <Download className="w-4 h-4" />
                  </button>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};

export default DocumentManager;