import React, { useState } from 'react';
import { Upload, FileText, Tag, Calendar, DollarSign, Check, X, AlertCircle, TrendingUp, TrendingDown } from 'lucide-react';

interface BankTransaction {
  id: string;
  date: string;
  description: string;
  debit: number;
  credit: number;
  balance: number;
  category?: string;
  isTagged: boolean;
  confidence: number;
  suggestedCategory?: string;
}

interface BankStatementData {
  accountNumber: string;
  startingBalance: number;
  endingBalance: number;
  statementPeriod: {
    from: string;
    to: string;
  };
  transactions: BankTransaction[];
}

const BankStatementUpload: React.FC = () => {
  const [isDragOver, setIsDragOver] = useState(false);
  const [uploadedFile, setUploadedFile] = useState<File | null>(null);
  const [statementData, setStatementData] = useState<BankStatementData | null>(null);
  const [isProcessing, setIsProcessing] = useState(false);
  const [processingStage, setProcessingStage] = useState('');

  const categories = [
    'Customer Payment',
    'Supplier Payment',
    'Salary & Benefits',
    'Tax Payment',
    'Bank Fees & Charges',
    'Office Expenses',
    'Travel & Entertainment',
    'Utilities',
    'Insurance',
    'Marketing & Advertising',
    'Professional Services',
    'Equipment Purchase',
    'Loan Payment',
    'Interest Income',
    'Other Income',
    'Other Expense'
  ];

  const handleDragOver = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragOver(true);
  };

  const handleDragLeave = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragOver(false);
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragOver(false);
    
    const files = Array.from(e.dataTransfer.files);
    if (files.length > 0) {
      processFile(files[0]);
    }
  };

  const handleFileSelect = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      processFile(e.target.files[0]);
    }
  };

  const processFile = (file: File) => {
    setUploadedFile(file);
    setIsProcessing(true);
    setProcessingStage('Uploading document...');

    // Simulate OCR + AI processing stages
    const stages = [
      'Uploading document...',
      'Running OCR extraction...',
      'Analyzing transaction patterns...',
      'Applying AI categorization...',
      'Finalizing data extraction...'
    ];

    let currentStage = 0;
    const stageInterval = setInterval(() => {
      if (currentStage < stages.length - 1) {
        currentStage++;
        setProcessingStage(stages[currentStage]);
      } else {
        clearInterval(stageInterval);
        
        // Mock extracted data with AI suggestions
        const mockStatementData: BankStatementData = {
          accountNumber: '****1234',
          startingBalance: 15420.50,
          endingBalance: 18750.25,
          statementPeriod: {
            from: '2024-01-01',
            to: '2024-01-31'
          },
          transactions: [
            {
              id: '1',
              date: '2024-01-15',
              description: 'PAYMENT FROM ABC CORP LTD - INV2024001',
              debit: 0,
              credit: 2500.00,
              balance: 17920.50,
              isTagged: false,
              confidence: 0.95,
              suggestedCategory: 'Customer Payment'
            },
            {
              id: '2',
              date: '2024-01-14',
              description: 'DIRECT DEBIT - OFFICE RENT PAYMENT',
              debit: 1200.00,
              credit: 0,
              balance: 15420.50,
              isTagged: false,
              confidence: 0.88,
              suggestedCategory: 'Office Expenses'
            },
            {
              id: '3',
              date: '2024-01-13',
              description: 'CARD PAYMENT - STAPLES OFFICE SUPPLIES',
              debit: 89.50,
              credit: 0,
              balance: 16620.50,
              isTagged: false,
              confidence: 0.92,
              suggestedCategory: 'Office Expenses'
            },
            {
              id: '4',
              date: '2024-01-12',
              description: 'SALARY PAYMENT - JOHN SMITH',
              debit: 3500.00,
              credit: 0,
              balance: 16710.00,
              isTagged: false,
              confidence: 0.98,
              suggestedCategory: 'Salary & Benefits'
            },
            {
              id: '5',
              date: '2024-01-11',
              description: 'HMRC VAT PAYMENT - Q4 2023',
              debit: 850.00,
              credit: 0,
              balance: 20210.00,
              isTagged: false,
              confidence: 0.96,
              suggestedCategory: 'Tax Payment'
            },
            {
              id: '6',
              date: '2024-01-10',
              description: 'BANK CHARGES - MONTHLY FEE',
              debit: 25.00,
              credit: 0,
              balance: 21060.00,
              isTagged: false,
              confidence: 0.99,
              suggestedCategory: 'Bank Fees & Charges'
            }
          ]
        };
        
        setStatementData(mockStatementData);
        setIsProcessing(false);
      }
    }, 800);
  };

  const handleCategoryChange = (transactionId: string, category: string) => {
    if (!statementData) return;
    
    const updatedTransactions = statementData.transactions.map(transaction => 
      transaction.id === transactionId 
        ? { ...transaction, category, isTagged: true }
        : transaction
    );
    
    setStatementData({
      ...statementData,
      transactions: updatedTransactions
    });
  };

  const acceptSuggestion = (transactionId: string) => {
    if (!statementData) return;
    
    const transaction = statementData.transactions.find(t => t.id === transactionId);
    if (transaction?.suggestedCategory) {
      handleCategoryChange(transactionId, transaction.suggestedCategory);
    }
  };

  const formatAmount = (amount: number) => {
    return `£${Math.abs(amount).toLocaleString('en-GB', { minimumFractionDigits: 2 })}`;
  };

  const getConfidenceColor = (confidence: number) => {
    if (confidence >= 0.9) return 'text-green-600';
    if (confidence >= 0.7) return 'text-yellow-600';
    return 'text-red-600';
  };

  const taggedCount = statementData?.transactions.filter(t => t.isTagged).length || 0;
  const totalCount = statementData?.transactions.length || 0;

  const handleSubmitForReview = () => {
    if (!statementData || !uploadedFile) return;
    
    // Simulate sending to admin interface
    alert('Bank statement data submitted for admin review successfully!');
  };

  return (
    <div className="space-y-6">
      {/* Upload Area */}
      <div
        className={`border-2 border-dashed rounded-lg p-8 text-center transition-colors ${
          isDragOver ? 'border-blue-500 bg-blue-50' : 'border-gray-300 bg-gray-50'
        }`}
        onDragOver={handleDragOver}
        onDragLeave={handleDragLeave}
        onDrop={handleDrop}
      >
        <FileText className="w-12 h-12 text-blue-500 mx-auto mb-4" />
        <h3 className="text-lg font-semibold text-gray-900 mb-2">Upload Bank Statement</h3>
        <p className="text-gray-600 mb-4">
          Our AI will automatically extract transactions and suggest categories
        </p>
        <div className="space-y-2">
          <p className="text-sm text-gray-500">
            Supported formats: PDF, CSV, Excel
          </p>
          <p className="text-sm text-gray-500">
            Maximum file size: 10MB
          </p>
        </div>
        <input
          type="file"
          accept=".pdf,.csv,.xls,.xlsx"
          onChange={handleFileSelect}
          className="hidden"
          id="bank-statement-upload"
        />
        <label
          htmlFor="bank-statement-upload"
          className="mt-4 inline-flex items-center px-4 py-2 border border-transparent text-sm font-medium rounded-md text-white bg-blue-600 hover:bg-blue-700 cursor-pointer"
        >
          <Upload className="w-4 h-4 mr-2" />
          Select Bank Statement
        </label>
      </div>

      {/* Processing State */}
      {isProcessing && (
        <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-6">
          <div className="flex items-center justify-center space-x-3 mb-4">
            <div className="w-6 h-6 border-2 border-blue-600 border-t-transparent rounded-full animate-spin"></div>
            <span className="text-gray-700 font-medium">Processing with AI...</span>
          </div>
          <div className="text-center">
            <p className="text-sm text-gray-600">{processingStage}</p>
            <div className="mt-3 w-full bg-gray-200 rounded-full h-2">
              <div className="bg-blue-600 h-2 rounded-full transition-all duration-500" style={{ width: '60%' }}></div>
            </div>
          </div>
        </div>
      )}

      {/* Statement Summary */}
      {statementData && !isProcessing && (
        <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-6">
          <h3 className="text-lg font-semibold text-gray-900 mb-4">Statement Summary</h3>
          <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
            <div className="bg-gray-50 rounded-lg p-4">
              <p className="text-sm text-gray-600">Account</p>
              <p className="text-lg font-semibold text-gray-900">{statementData.accountNumber}</p>
            </div>
            <div className="bg-gray-50 rounded-lg p-4">
              <p className="text-sm text-gray-600">Period</p>
              <p className="text-lg font-semibold text-gray-900">
                {new Date(statementData.statementPeriod.from).toLocaleDateString()} - {new Date(statementData.statementPeriod.to).toLocaleDateString()}
              </p>
            </div>
            <div className="bg-gray-50 rounded-lg p-4">
              <div className="flex items-center space-x-2">
                <TrendingUp className="w-5 h-5 text-green-600" />
                <div>
                  <p className="text-sm text-gray-600">Starting Balance</p>
                  <p className="text-lg font-semibold text-gray-900">{formatAmount(statementData.startingBalance)}</p>
                </div>
              </div>
            </div>
            <div className="bg-gray-50 rounded-lg p-4">
              <div className="flex items-center space-x-2">
                <TrendingDown className="w-5 h-5 text-blue-600" />
                <div>
                  <p className="text-sm text-gray-600">Ending Balance</p>
                  <p className="text-lg font-semibold text-gray-900">{formatAmount(statementData.endingBalance)}</p>
                </div>
              </div>
            </div>
          </div>
          
          <div className="mt-4 flex items-center justify-between">
            <span className="text-sm text-gray-600">
              Tagged: {taggedCount}/{totalCount} transactions
            </span>
            <div className="w-32 bg-gray-200 rounded-full h-2">
              <div 
                className="bg-blue-600 h-2 rounded-full transition-all"
                style={{ width: `${totalCount > 0 ? (taggedCount / totalCount) * 100 : 0}%` }}
              ></div>
            </div>
          </div>
        </div>
      )}

      {/* Transactions Table */}
      {statementData && (
        <div className="bg-white rounded-lg shadow-sm border border-gray-200">
          <div className="p-4 border-b border-gray-200">
            <h3 className="text-lg font-semibold text-gray-900">Bank Transactions</h3>
            <p className="text-sm text-gray-500">Review AI suggestions and tag each transaction</p>
          </div>
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead className="bg-gray-50">
                <tr>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Date
                  </th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Description
                  </th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Debit
                  </th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Credit
                  </th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Balance
                  </th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    AI Suggestion
                  </th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Category
                  </th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Status
                  </th>
                </tr>
              </thead>
              <tbody className="bg-white divide-y divide-gray-200">
                {statementData.transactions.map((transaction) => (
                  <tr key={transaction.id} className="hover:bg-gray-50">
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                      <div className="flex items-center space-x-2">
                        <Calendar className="w-4 h-4 text-gray-400" />
                        <span>{new Date(transaction.date).toLocaleDateString('en-GB')}</span>
                      </div>
                    </td>
                    <td className="px-6 py-4 text-sm text-gray-900 max-w-xs">
                      <div className="truncate" title={transaction.description}>
                        {transaction.description}
                      </div>
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm font-medium">
                      {transaction.debit > 0 ? (
                        <span className="text-red-600">-{formatAmount(transaction.debit)}</span>
                      ) : (
                        <span className="text-gray-400">-</span>
                      )}
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm font-medium">
                      {transaction.credit > 0 ? (
                        <span className="text-green-600">+{formatAmount(transaction.credit)}</span>
                      ) : (
                        <span className="text-gray-400">-</span>
                      )}
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                      {formatAmount(transaction.balance)}
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap">
                      {transaction.suggestedCategory && (
                        <div className="flex items-center space-x-2">
                          <span className={`text-xs ${getConfidenceColor(transaction.confidence)}`}>
                            {Math.round(transaction.confidence * 100)}%
                          </span>
                          <span className="text-sm text-gray-700">{transaction.suggestedCategory}</span>
                          <button
                            onClick={() => acceptSuggestion(transaction.id)}
                            className="text-blue-600 hover:text-blue-800 text-xs"
                          >
                            Accept
                          </button>
                        </div>
                      )}
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap">
                      <select
                        value={transaction.category || ''}
                        onChange={(e) => handleCategoryChange(transaction.id, e.target.value)}
                        className="text-sm border border-gray-300 rounded-md px-3 py-1 focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                      >
                        <option value="">Select category...</option>
                        {categories.map(category => (
                          <option key={category} value={category}>{category}</option>
                        ))}
                      </select>
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap">
                      {transaction.isTagged ? (
                        <div className="flex items-center space-x-2 text-green-600">
                          <Check className="w-4 h-4" />
                          <span className="text-sm">Tagged</span>
                        </div>
                      ) : (
                        <div className="flex items-center space-x-2 text-yellow-600">
                          <Tag className="w-4 h-4" />
                          <span className="text-sm">Pending</span>
                        </div>
                      )}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
          <div className="p-4 border-t border-gray-200 bg-gray-50">
            <div className="flex items-center justify-between">
              <span className="text-sm text-gray-600">
                {taggedCount} of {totalCount} transactions tagged
              </span>
              <button
                onClick={handleSubmitForReview}
                disabled={taggedCount !== totalCount}
                className="px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 disabled:opacity-50 disabled:cursor-not-allowed transition-colors"
              >
                Submit for Admin Review
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default BankStatementUpload;