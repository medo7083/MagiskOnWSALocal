import React, { useState } from 'react';
import { Upload, FileText, Eye, Edit, Check, X, Building, Calendar, DollarSign, Hash, AlertCircle } from 'lucide-react';

interface ExtractedData {
  invoiceNumber: string;
  invoiceDate: string;
  dueDate: string;
  supplierName: string;
  supplierAddress: string;
  customerName: string;
  customerAddress: string;
  netAmount: number;
  vatAmount: number;
  totalAmount: number;
  vatRate: number;
  currency: string;
  accountingNature: string;
  suggestedLedgerAccount: string;
  confidence: number;
  lineItems: {
    description: string;
    quantity: number;
    unitPrice: number;
    amount: number;
  }[];
}

interface UploadedInvoice {
  id: string;
  file: File;
  previewUrl: string;
  extractedData: ExtractedData;
  status: 'processing' | 'extracted' | 'validated' | 'submitted';
  uploadDate: string;
  processingStage: string;
}

const InvoiceUpload: React.FC = () => {
  const [isDragOver, setIsDragOver] = useState(false);
  const [uploadedInvoices, setUploadedInvoices] = useState<UploadedInvoice[]>([]);
  const [selectedInvoice, setSelectedInvoice] = useState<UploadedInvoice | null>(null);
  const [isEditing, setIsEditing] = useState(false);

  const accountingNatures = [
    'Office Supplies',
    'Professional Services',
    'Marketing & Advertising',
    'Travel & Entertainment',
    'Utilities',
    'Insurance',
    'Equipment Purchase',
    'Software & Subscriptions',
    'Rent & Facilities',
    'Maintenance & Repairs',
    'Training & Development',
    'Legal & Compliance',
    'Other Expenses'
  ];

  const suggestedLedgerAccounts = [
    '5000 - Office Expenses',
    '5100 - Professional Fees',
    '5200 - Marketing Expenses',
    '5300 - Travel & Entertainment',
    '5400 - Utilities',
    '5500 - Insurance',
    '1200 - Equipment',
    '5600 - Software & IT',
    '5700 - Rent',
    '5800 - Maintenance',
    '5900 - Training',
    '6000 - Legal & Professional'
  ];

  const handleDragOver = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragOver(true);
  };

  const handleDragLeave = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragOver(false);
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragOver(false);
    
    const files = Array.from(e.dataTransfer.files);
    files.forEach(file => processFile(file));
  };

  const handleFileSelect = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files) {
      Array.from(e.target.files).forEach(file => processFile(file));
    }
  };

  const processFile = (file: File) => {
    const previewUrl = URL.createObjectURL(file);
    
    const newInvoice: UploadedInvoice = {
      id: Date.now().toString() + Math.random(),
      file,
      previewUrl,
      extractedData: {
        invoiceNumber: '',
        invoiceDate: '',
        dueDate: '',
        supplierName: '',
        supplierAddress: '',
        customerName: '',
        customerAddress: '',
        netAmount: 0,
        vatAmount: 0,
        totalAmount: 0,
        vatRate: 0,
        currency: 'GBP',
        accountingNature: '',
        suggestedLedgerAccount: '',
        confidence: 0,
        lineItems: []
      },
      status: 'processing',
      uploadDate: new Date().toISOString(),
      processingStage: 'Uploading...'
    };

    setUploadedInvoices(prev => [...prev, newInvoice]);

    // Simulate OCR + AI processing stages
    const stages = [
      'Uploading document...',
      'Running OCR extraction...',
      'Analyzing invoice structure...',
      'Extracting financial data...',
      'Applying AI categorization...',
      'Matching supplier database...',
      'Suggesting ledger accounts...',
      'Finalizing extraction...'
    ];

    let currentStage = 0;
    const stageInterval = setInterval(() => {
      setUploadedInvoices(prev => prev.map(invoice => 
        invoice.id === newInvoice.id 
          ? { ...invoice, processingStage: stages[currentStage] }
          : invoice
      ));

      if (currentStage < stages.length - 1) {
        currentStage++;
      } else {
        clearInterval(stageInterval);
        
        // Mock extracted data with high-confidence AI results
        const mockExtractedData: ExtractedData = {
          invoiceNumber: 'INV-2024-001',
          invoiceDate: '2024-01-15',
          dueDate: '2024-02-14',
          supplierName: 'ABC Office Supplies Ltd',
          supplierAddress: '123 Business Park, London, UK',
          customerName: 'Your Company Ltd',
          customerAddress: '456 Corporate Street, London, UK',
          netAmount: 1250.00,
          vatAmount: 250.00,
          totalAmount: 1500.00,
          vatRate: 20,
          currency: 'GBP',
          accountingNature: 'Office Supplies',
          suggestedLedgerAccount: '5000 - Office Expenses',
          confidence: 0.94,
          lineItems: [
            {
              description: 'Premium Paper A4 - 500 sheets',
              quantity: 10,
              unitPrice: 8.50,
              amount: 85.00
            },
            {
              description: 'Ink Cartridges - Black',
              quantity: 5,
              unitPrice: 45.00,
              amount: 225.00
            },
            {
              description: 'Office Chairs - Ergonomic',
              quantity: 2,
              unitPrice: 470.00,
              amount: 940.00
            }
          ]
        };

        setUploadedInvoices(prev => prev.map(invoice => 
          invoice.id === newInvoice.id 
            ? { ...invoice, extractedData: mockExtractedData, status: 'extracted' }
            : invoice
        ));
      }
    }, 600);
  };

  const handleValidateInvoice = (invoiceId: string) => {
    setUploadedInvoices(prev => prev.map(invoice => 
      invoice.id === invoiceId 
        ? { ...invoice, status: 'validated' }
        : invoice
    ));
  };

  const handleSubmitInvoice = (invoiceId: string) => {
    setUploadedInvoices(prev => prev.map(invoice => 
      invoice.id === invoiceId 
        ? { ...invoice, status: 'submitted' }
        : invoice
    ));
    
    alert('Invoice submitted for admin review successfully!');
  };

  const updateExtractedData = (field: string, value: any) => {
    if (!selectedInvoice) return;
    
    setUploadedInvoices(prev => prev.map(invoice => 
      invoice.id === selectedInvoice.id 
        ? { 
            ...invoice, 
            extractedData: { 
              ...invoice.extractedData, 
              [field]: value 
            } 
          }
        : invoice
    ));
    
    setSelectedInvoice(prev => prev ? {
      ...prev,
      extractedData: {
        ...prev.extractedData,
        [field]: value
      }
    } : null);
  };

  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'processing':
        return <div className="w-4 h-4 border-2 border-blue-500 border-t-transparent rounded-full animate-spin" />;
      case 'extracted':
        return <AlertCircle className="w-4 h-4 text-yellow-500" />;
      case 'validated':
        return <Check className="w-4 h-4 text-green-500" />;
      case 'submitted':
        return <Check className="w-4 h-4 text-gray-500" />;
      default:
        return <AlertCircle className="w-4 h-4 text-gray-500" />;
    }
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'processing':
        return 'bg-blue-100 text-blue-800';
      case 'extracted':
        return 'bg-yellow-100 text-yellow-800';
      case 'validated':
        return 'bg-green-100 text-green-800';
      case 'submitted':
        return 'bg-gray-100 text-gray-800';
      default:
        return 'bg-gray-100 text-gray-800';
    }
  };

  const getConfidenceColor = (confidence: number) => {
    if (confidence >= 0.9) return 'text-green-600';
    if (confidence >= 0.7) return 'text-yellow-600';
    return 'text-red-600';
  };

  const formatAmount = (amount: number) => {
    return `£${amount.toLocaleString('en-GB', { minimumFractionDigits: 2 })}`;
  };

  return (
    <div className="space-y-6">
      {/* Upload Area */}
      <div
        className={`border-2 border-dashed rounded-lg p-8 text-center transition-colors ${
          isDragOver ? 'border-green-500 bg-green-50' : 'border-gray-300 bg-gray-50'
        }`}
        onDragOver={handleDragOver}
        onDragLeave={handleDragLeave}
        onDrop={handleDrop}
      >
        <FileText className="w-12 h-12 text-green-500 mx-auto mb-4" />
        <h3 className="text-lg font-semibold text-gray-900 mb-2">Upload Invoices</h3>
        <p className="text-gray-600 mb-4">
          Our AI will automatically extract all invoice data and suggest accounting categories
        </p>
        <div className="space-y-2">
          <p className="text-sm text-gray-500">
            Supported formats: PDF, JPG, PNG
          </p>
          <p className="text-sm text-gray-500">
            Maximum file size: 10MB per file
          </p>
        </div>
        <input
          type="file"
          multiple
          accept=".pdf,.jpg,.jpeg,.png"
          onChange={handleFileSelect}
          className="hidden"
          id="invoice-upload"
        />
        <label
          htmlFor="invoice-upload"
          className="mt-4 inline-flex items-center px-4 py-2 border border-transparent text-sm font-medium rounded-md text-white bg-green-600 hover:bg-green-700 cursor-pointer"
        >
          <Upload className="w-4 h-4 mr-2" />
          Select Invoices
        </label>
      </div>

      {/* Uploaded Invoices */}
      {uploadedInvoices.length > 0 && (
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          {/* Invoice List */}
          <div className="bg-white rounded-lg shadow-sm border border-gray-200">
            <div className="p-4 border-b border-gray-200">
              <h3 className="text-lg font-semibold text-gray-900">Uploaded Invoices</h3>
            </div>
            <div className="p-4 space-y-3">
              {uploadedInvoices.map((invoice) => (
                <div 
                  key={invoice.id} 
                  className={`p-3 border rounded-lg cursor-pointer transition-colors ${
                    selectedInvoice?.id === invoice.id ? 'border-green-500 bg-green-50' : 'border-gray-200 hover:bg-gray-50'
                  }`}
                  onClick={() => setSelectedInvoice(invoice)}
                >
                  <div className="flex items-center justify-between">
                    <div className="flex items-center space-x-3">
                      <FileText className="w-6 h-6 text-gray-400" />
                      <div>
                        <p className="text-sm font-medium text-gray-900 truncate">
                          {invoice.file.name}
                        </p>
                        <p className="text-xs text-gray-500">
                          {new Date(invoice.uploadDate).toLocaleDateString()}
                        </p>
                      </div>
                    </div>
                    <div className="flex items-center space-x-2">
                      <span className={`inline-flex px-2 py-1 text-xs font-semibold rounded-full ${getStatusColor(invoice.status)}`}>
                        {invoice.status}
                      </span>
                      {getStatusIcon(invoice.status)}
                    </div>
                  </div>
                  
                  {invoice.status === 'processing' && (
                    <div className="mt-2">
                      <p className="text-xs text-gray-600">{invoice.processingStage}</p>
                      <div className="mt-1 w-full bg-gray-200 rounded-full h-1">
                        <div className="bg-green-600 h-1 rounded-full transition-all duration-500" style={{ width: '60%' }}></div>
                      </div>
                    </div>
                  )}
                  
                  {invoice.status === 'extracted' && invoice.extractedData.confidence > 0 && (
                    <div className="mt-2 flex items-center justify-between">
                      <span className="text-xs text-gray-600">
                        AI Confidence: <span className={getConfidenceColor(invoice.extractedData.confidence)}>
                          {Math.round(invoice.extractedData.confidence * 100)}%
                        </span>
                      </span>
                      {invoice.extractedData.invoiceNumber && (
                        <span className="text-xs text-gray-600">
                          {invoice.extractedData.invoiceNumber}
                        </span>
                      )}
                    </div>
                  )}
                </div>
              ))}
            </div>
          </div>

          {/* Invoice Details */}
          {selectedInvoice && (
            <div className="bg-white rounded-lg shadow-sm border border-gray-200">
              <div className="p-4 border-b border-gray-200">
                <div className="flex items-center justify-between">
                  <h3 className="text-lg font-semibold text-gray-900">Invoice Details</h3>
                  <div className="flex items-center space-x-2">
                    <button
                      onClick={() => setIsEditing(!isEditing)}
                      className="p-2 text-gray-400 hover:text-gray-600"
                      disabled={selectedInvoice.status === 'processing'}
                    >
                      <Edit className="w-4 h-4" />
                    </button>
                    <button className="p-2 text-gray-400 hover:text-gray-600">
                      <Eye className="w-4 h-4" />
                    </button>
                  </div>
                </div>
              </div>
              
              <div className="p-4 space-y-4 max-h-96 overflow-y-auto">
                {selectedInvoice.status === 'processing' ? (
                  <div className="text-center py-8">
                    <div className="w-8 h-8 border-2 border-green-600 border-t-transparent rounded-full animate-spin mx-auto mb-4"></div>
                    <p className="text-gray-600 font-medium">Processing with AI...</p>
                    <p className="text-sm text-gray-500 mt-2">{selectedInvoice.processingStage}</p>
                  </div>
                ) : (
                  <>
                    {/* AI Confidence Score */}
                    {selectedInvoice.extractedData.confidence > 0 && (
                      <div className="bg-gray-50 rounded-lg p-3">
                        <div className="flex items-center justify-between">
                          <span className="text-sm font-medium text-gray-700">AI Extraction Confidence</span>
                          <span className={`text-sm font-semibold ${getConfidenceColor(selectedInvoice.extractedData.confidence)}`}>
                            {Math.round(selectedInvoice.extractedData.confidence * 100)}%
                          </span>
                        </div>
                        <div className="mt-2 w-full bg-gray-200 rounded-full h-2">
                          <div 
                            className={`h-2 rounded-full ${
                              selectedInvoice.extractedData.confidence >= 0.9 ? 'bg-green-500' :
                              selectedInvoice.extractedData.confidence >= 0.7 ? 'bg-yellow-500' : 'bg-red-500'
                            }`}
                            style={{ width: `${selectedInvoice.extractedData.confidence * 100}%` }}
                          ></div>
                        </div>
                      </div>
                    )}

                    {/* Basic Invoice Info */}
                    <div className="grid grid-cols-2 gap-4">
                      <div>
                        <label className="block text-sm font-medium text-gray-700 mb-1">
                          Invoice Number
                        </label>
                        <div className="flex items-center space-x-2">
                          <Hash className="w-4 h-4 text-gray-400" />
                          <input
                            type="text"
                            value={selectedInvoice.extractedData.invoiceNumber}
                            onChange={(e) => updateExtractedData('invoiceNumber', e.target.value)}
                            disabled={!isEditing}
                            className="flex-1 text-sm border border-gray-300 rounded px-3 py-2 disabled:bg-gray-50"
                          />
                        </div>
                      </div>
                      <div>
                        <label className="block text-sm font-medium text-gray-700 mb-1">
                          Invoice Date
                        </label>
                        <div className="flex items-center space-x-2">
                          <Calendar className="w-4 h-4 text-gray-400" />
                          <input
                            type="date"
                            value={selectedInvoice.extractedData.invoiceDate}
                            onChange={(e) => updateExtractedData('invoiceDate', e.target.value)}
                            disabled={!isEditing}
                            className="flex-1 text-sm border border-gray-300 rounded px-3 py-2 disabled:bg-gray-50"
                          />
                        </div>
                      </div>
                    </div>

                    {/* Supplier Info */}
                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-1">
                        Supplier Name
                      </label>
                      <div className="flex items-center space-x-2">
                        <Building className="w-4 h-4 text-gray-400" />
                        <input
                          type="text"
                          value={selectedInvoice.extractedData.supplierName}
                          onChange={(e) => updateExtractedData('supplierName', e.target.value)}
                          disabled={!isEditing}
                          className="flex-1 text-sm border border-gray-300 rounded px-3 py-2 disabled:bg-gray-50"
                        />
                      </div>
                    </div>

                    {/* Financial Data */}
                    <div className="grid grid-cols-3 gap-4">
                      <div>
                        <label className="block text-sm font-medium text-gray-700 mb-1">
                          Net Amount
                        </label>
                        <div className="flex items-center space-x-2">
                          <DollarSign className="w-4 h-4 text-gray-400" />
                          <input
                            type="number"
                            step="0.01"
                            value={selectedInvoice.extractedData.netAmount}
                            onChange={(e) => updateExtractedData('netAmount', parseFloat(e.target.value))}
                            disabled={!isEditing}
                            className="flex-1 text-sm border border-gray-300 rounded px-3 py-2 disabled:bg-gray-50"
                          />
                        </div>
                      </div>
                      <div>
                        <label className="block text-sm font-medium text-gray-700 mb-1">
                          VAT Amount
                        </label>
                        <input
                          type="number"
                          step="0.01"
                          value={selectedInvoice.extractedData.vatAmount}
                          onChange={(e) => updateExtractedData('vatAmount', parseFloat(e.target.value))}
                          disabled={!isEditing}
                          className="w-full text-sm border border-gray-300 rounded px-3 py-2 disabled:bg-gray-50"
                        />
                      </div>
                      <div>
                        <label className="block text-sm font-medium text-gray-700 mb-1">
                          Total Amount
                        </label>
                        <input
                          type="number"
                          step="0.01"
                          value={selectedInvoice.extractedData.totalAmount}
                          onChange={(e) => updateExtractedData('totalAmount', parseFloat(e.target.value))}
                          disabled={!isEditing}
                          className="w-full text-sm border border-gray-300 rounded px-3 py-2 disabled:bg-gray-50"
                        />
                      </div>
                    </div>

                    {/* Accounting Classification */}
                    <div className="grid grid-cols-1 gap-4">
                      <div>
                        <label className="block text-sm font-medium text-gray-700 mb-1">
                          Accounting Nature
                        </label>
                        <select
                          value={selectedInvoice.extractedData.accountingNature}
                          onChange={(e) => updateExtractedData('accountingNature', e.target.value)}
                          disabled={!isEditing}
                          className="w-full text-sm border border-gray-300 rounded px-3 py-2 disabled:bg-gray-50"
                        >
                          <option value="">Select nature...</option>
                          {accountingNatures.map(nature => (
                            <option key={nature} value={nature}>{nature}</option>
                          ))}
                        </select>
                      </div>
                      <div>
                        <label className="block text-sm font-medium text-gray-700 mb-1">
                          Suggested Ledger Account
                        </label>
                        <select
                          value={selectedInvoice.extractedData.suggestedLedgerAccount}
                          onChange={(e) => updateExtractedData('suggestedLedgerAccount', e.target.value)}
                          disabled={!isEditing}
                          className="w-full text-sm border border-gray-300 rounded px-3 py-2 disabled:bg-gray-50"
                        >
                          <option value="">Select account...</option>
                          {suggestedLedgerAccounts.map(account => (
                            <option key={account} value={account}>{account}</option>
                          ))}
                        </select>
                      </div>
                    </div>

                    {/* Line Items */}
                    {selectedInvoice.extractedData.lineItems.length > 0 && (
                      <div>
                        <h4 className="text-sm font-medium text-gray-700 mb-2">Line Items</h4>
                        <div className="space-y-2">
                          {selectedInvoice.extractedData.lineItems.map((item, index) => (
                            <div key={index} className="bg-gray-50 rounded p-2 text-xs">
                              <div className="flex justify-between">
                                <span className="font-medium">{item.description}</span>
                                <span>{formatAmount(item.amount)}</span>
                              </div>
                              <div className="text-gray-500">
                                Qty: {item.quantity} × {formatAmount(item.unitPrice)}
                              </div>
                            </div>
                          ))}
                        </div>
                      </div>
                    )}

                    {/* Action Buttons */}
                    <div className="flex items-center justify-between pt-4 border-t border-gray-200">
                      <div className="text-sm text-gray-600">
                        Status: <span className="font-medium">{selectedInvoice.status}</span>
                      </div>
                      <div className="flex items-center space-x-2">
                        {selectedInvoice.status === 'extracted' && (
                          <button
                            onClick={() => handleValidateInvoice(selectedInvoice.id)}
                            className="px-3 py-1 bg-blue-600 text-white text-sm rounded hover:bg-blue-700"
                          >
                            <Check className="w-4 h-4 inline mr-1" />
                            Validate
                          </button>
                        )}
                        {selectedInvoice.status === 'validated' && (
                          <button
                            onClick={() => handleSubmitInvoice(selectedInvoice.id)}
                            className="px-3 py-1 bg-green-600 text-white text-sm rounded hover:bg-green-700"
                          >
                            Submit for Admin Review
                          </button>
                        )}
                      </div>
                    </div>
                  </>
                )}
              </div>
            </div>
          )}
        </div>
      )}
    </div>
  );
};

export default InvoiceUpload;