import React, { useState } from 'react';
import { FileText, Receipt, ArrowLeft } from 'lucide-react';
import BankStatementUpload from './BankStatementUpload';
import InvoiceUpload from './InvoiceUpload';

type UploadMode = 'selection' | 'bank-statements' | 'invoices';

const UploadArea: React.FC = () => {
  const [uploadMode, setUploadMode] = useState<UploadMode>('selection');

  const renderContent = () => {
    switch (uploadMode) {
      case 'bank-statements':
        return <BankStatementUpload />;
      case 'invoices':
        return <InvoiceUpload />;
      default:
        return (
          <div className="space-y-6">
            <div className="text-center mb-8">
              <h2 className="text-2xl font-bold text-gray-900 mb-2">Upload Documents</h2>
              <p className="text-gray-600">Choose the type of document you want to upload</p>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-6 max-w-4xl mx-auto">
              {/* Bank Statements */}
              <div 
                onClick={() => setUploadMode('bank-statements')}
                className="bg-white rounded-xl shadow-sm border border-gray-200 p-8 text-center cursor-pointer hover:shadow-md hover:border-blue-300 transition-all group"
              >
                <div className="w-16 h-16 bg-gradient-to-br from-blue-500 to-blue-600 rounded-xl flex items-center justify-center mx-auto mb-4 group-hover:scale-105 transition-transform">
                  <FileText className="w-8 h-8 text-white" />
                </div>
                <h3 className="text-xl font-semibold text-gray-900 mb-2">Bank Statements</h3>
                <p className="text-gray-600 mb-4">
                  Upload your bank statements and tag each transaction with the appropriate category
                </p>
                <div className="space-y-2 text-sm text-gray-500">
                  <p>• Automatic transaction extraction</p>
                  <p>• Manual categorization</p>
                  <p>• PDF, CSV, Excel support</p>
                </div>
                <div className="mt-6">
                  <span className="inline-flex items-center px-4 py-2 bg-blue-50 text-blue-700 rounded-lg text-sm font-medium">
                    Upload Bank Statement
                  </span>
                </div>
              </div>

              {/* Invoices */}
              <div 
                onClick={() => setUploadMode('invoices')}
                className="bg-white rounded-xl shadow-sm border border-gray-200 p-8 text-center cursor-pointer hover:shadow-md hover:border-green-300 transition-all group"
              >
                <div className="w-16 h-16 bg-gradient-to-br from-green-500 to-green-600 rounded-xl flex items-center justify-center mx-auto mb-4 group-hover:scale-105 transition-transform">
                  <Receipt className="w-8 h-8 text-white" />
                </div>
                <h3 className="text-xl font-semibold text-gray-900 mb-2">Invoices</h3>
                <p className="text-gray-600 mb-4">
                  Upload purchase or sales invoices with automatic data extraction and validation
                </p>
                <div className="space-y-2 text-sm text-gray-500">
                  <p>• OCR data extraction</p>
                  <p>• Admin validation workflow</p>
                  <p>• PDF, JPG, PNG support</p>
                </div>
                <div className="mt-6">
                  <span className="inline-flex items-center px-4 py-2 bg-green-50 text-green-700 rounded-lg text-sm font-medium">
                    Upload Invoices
                  </span>
                </div>
              </div>
            </div>

            {/* Features Overview */}
            <div className="bg-gradient-to-r from-blue-50 to-green-50 rounded-xl p-6 mt-8">
              <h3 className="text-lg font-semibold text-gray-900 mb-4">Why Upload Your Documents?</h3>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                <div className="text-center">
                  <div className="w-12 h-12 bg-blue-100 rounded-lg flex items-center justify-center mx-auto mb-2">
                    <FileText className="w-6 h-6 text-blue-600" />
                  </div>
                  <h4 className="font-medium text-gray-900 mb-1">Automated Processing</h4>
                  <p className="text-sm text-gray-600">AI-powered extraction and classification</p>
                </div>
                <div className="text-center">
                  <div className="w-12 h-12 bg-green-100 rounded-lg flex items-center justify-center mx-auto mb-2">
                    <Receipt className="w-6 h-6 text-green-600" />
                  </div>
                  <h4 className="font-medium text-gray-900 mb-1">Real-time Updates</h4>
                  <p className="text-sm text-gray-600">See your financial data update instantly</p>
                </div>
                <div className="text-center">
                  <div className="w-12 h-12 bg-purple-100 rounded-lg flex items-center justify-center mx-auto mb-2">
                    <FileText className="w-6 h-6 text-purple-600" />
                  </div>
                  <h4 className="font-medium text-gray-900 mb-1">Secure Storage</h4>
                  <p className="text-sm text-gray-600">Bank-level security for your documents</p>
                </div>
              </div>
            </div>
          </div>
        );
    }
  };

  return (
    <div className="space-y-6">
      {uploadMode !== 'selection' && (
        <div className="flex items-center space-x-4">
          <button
            onClick={() => setUploadMode('selection')}
            className="flex items-center space-x-2 text-gray-600 hover:text-gray-900 transition-colors"
          >
            <ArrowLeft className="w-4 h-4" />
            <span>Back to Document Types</span>
          </button>
          <div className="h-4 w-px bg-gray-300"></div>
          <h1 className="text-xl font-semibold text-gray-900">
            {uploadMode === 'bank-statements' ? 'Bank Statements' : 'Invoices'}
          </h1>
        </div>
      )}
      
      {renderContent()}
    </div>
  );
};

export default UploadArea;