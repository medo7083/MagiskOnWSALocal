export interface User {
  id: string;
  name: string;
  email: string;
  company: {
    name: string;
    registrationNumber: string;
    taxId: string;
    address: string;
  };
}

export interface Transaction {
  id: string;
  date: string;
  description: string;
  amount: number;
  category: string;
  type: 'income' | 'expense';
  status: 'pending' | 'classified' | 'validated';
  bankAccount: string;
}

export interface Document {
  id: string;
  name: string;
  type: 'invoice' | 'bank_statement' | 'legal' | 'contract';
  uploadDate: string;
  size: string;
  status: 'processing' | 'ready' | 'validated';
}

export interface FinancialMetric {
  label: string;
  value: number;
  change: number;
  period: string;
}

export interface ChatMessage {
  id: string;
  message: string;
  sender: 'user' | 'bot';
  timestamp: string;
}