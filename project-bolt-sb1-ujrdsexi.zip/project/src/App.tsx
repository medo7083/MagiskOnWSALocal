import React, { useState } from 'react';
import { AuthProvider, useAuth } from './contexts/AuthContext';
import { AdminProvider, useAdmin } from './contexts/AdminContext';
import LoginForm from './components/Auth/LoginForm';
import AdminLogin from './components/Admin/AdminLogin';
import AdminDashboard from './components/Admin/AdminDashboard';
import Sidebar from './components/Layout/Sidebar';
import Header from './components/Layout/Header';
import Dashboard from './components/Dashboard/Dashboard';
import UploadArea from './components/Upload/UploadArea';
import TransactionList from './components/Transactions/TransactionList';
import DocumentManager from './components/Documents/DocumentManager';
import ChatBot from './components/Chat/ChatBot';
import Settings from './components/Settings/Settings';

const AppContent: React.FC = () => {
  const { user, isLoading } = useAuth();
  const [activeTab, setActiveTab] = useState('dashboard');
  const [sidebarOpen, setSidebarOpen] = useState(false);

  if (isLoading) {
    return (
      <div className="min-h-screen bg-gray-100 flex items-center justify-center">
        <div className="text-center">
          <div className="w-16 h-16 border-4 border-blue-600 border-t-transparent rounded-full animate-spin mx-auto mb-4"></div>
          <p className="text-gray-600">Loading...</p>
        </div>
      </div>
    );
  }

  if (!user) {
    return <LoginForm />;
  }

  const getPageTitle = () => {
    switch (activeTab) {
      case 'dashboard':
        return 'Dashboard';
      case 'upload':
        return 'Upload Documents';
      case 'transactions':
        return 'Transactions';
      case 'documents':
        return 'Legal Folder';
      case 'chat':
        return 'AI Assistant';
      case 'settings':
        return 'Settings';
      default:
        return 'Dashboard';
    }
  };

  const renderContent = () => {
    switch (activeTab) {
      case 'dashboard':
        return <Dashboard />;
      case 'upload':
        return <UploadArea />;
      case 'transactions':
        return <TransactionList />;
      case 'documents':
        return <DocumentManager />;
      case 'chat':
        return <ChatBot />;
      case 'settings':
        return <Settings />;
      default:
        return <Dashboard />;
    }
  };

  return (
    <div className="min-h-screen bg-gray-100">
      <div className="flex h-screen">
        {/* Desktop Sidebar */}
        <div className="hidden md:block w-64 bg-white shadow-sm">
          <Sidebar activeTab={activeTab} setActiveTab={setActiveTab} />
        </div>

        {/* Mobile Sidebar */}
        {sidebarOpen && (
          <div className="fixed inset-0 z-50 md:hidden">
            <div className="fixed inset-0 bg-black bg-opacity-50" onClick={() => setSidebarOpen(false)} />
            <div className="fixed inset-y-0 left-0 w-64 bg-white shadow-sm">
              <Sidebar
                activeTab={activeTab}
                setActiveTab={setActiveTab}
                isMobile={true}
                onClose={() => setSidebarOpen(false)}
              />
            </div>
          </div>
        )}

        {/* Main Content */}
        <div className="flex-1 flex flex-col overflow-hidden">
          <Header
            onMenuToggle={() => setSidebarOpen(!sidebarOpen)}
            title={getPageTitle()}
          />
          <main className="flex-1 overflow-x-hidden overflow-y-auto p-6">
            {renderContent()}
          </main>
        </div>
      </div>
    </div>
  );
};

const AdminAppContent: React.FC = () => {
  const { adminUser, login, isLoading } = useAdmin();

  if (!adminUser) {
    return <AdminLogin onLogin={login} isLoading={isLoading} />;
  }

  return <AdminDashboard />;
};

const App: React.FC = () => {
  const [isAdminMode, setIsAdminMode] = useState(false);

  // Check URL for admin mode
  React.useEffect(() => {
    const urlParams = new URLSearchParams(window.location.search);
    if (urlParams.get('admin') === 'true') {
      setIsAdminMode(true);
    }
  }, []);

  if (isAdminMode) {
    return (
      <AdminProvider>
        <div className="min-h-screen">
          <AdminAppContent />
          <div className="fixed bottom-4 left-4">
            <button
              onClick={() => setIsAdminMode(false)}
              className="px-3 py-2 bg-gray-600 text-white text-sm rounded-lg hover:bg-gray-700 transition-colors"
            >
              Switch to Client View
            </button>
          </div>
        </div>
      </AdminProvider>
    );
  }

  return (
    <AuthProvider>
      <div className="min-h-screen">
        <AppContent />
        <div className="fixed bottom-4 left-4">
          <button
            onClick={() => setIsAdminMode(true)}
            className="px-3 py-2 bg-blue-600 text-white text-sm rounded-lg hover:bg-blue-700 transition-colors"
          >
            Admin Login
          </button>
        </div>
      </div>
    </AuthProvider>
  );
};

export default App;