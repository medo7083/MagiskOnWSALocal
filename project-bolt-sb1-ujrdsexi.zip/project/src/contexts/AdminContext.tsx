import React, { createContext, useContext, useState } from 'react';

interface AdminUser {
  id: string;
  name: string;
  email: string;
  role: 'admin' | 'super_admin';
}

interface AdminContextType {
  adminUser: AdminUser | null;
  login: (credentials: { email: string; password: string }) => Promise<void>;
  logout: () => void;
  isLoading: boolean;
}

const AdminContext = createContext<AdminContextType | undefined>(undefined);

export const useAdmin = () => {
  const context = useContext(AdminContext);
  if (!context) {
    throw new Error('useAdmin must be used within an AdminProvider');
  }
  return context;
};

export const AdminProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [adminUser, setAdminUser] = useState<AdminUser | null>(null);
  const [isLoading, setIsLoading] = useState(false);

  const login = async (credentials: { email: string; password: string }) => {
    setIsLoading(true);
    
    // Simulate API call
    await new Promise(resolve => setTimeout(resolve, 1000));
    
    // Simple validation for demo
    if (credentials.email === 'admin@smartbooks.com' && credentials.password === 'admin123') {
      const mockAdminUser: AdminUser = {
        id: 'admin-1',
        name: 'Admin User',
        email: credentials.email,
        role: 'admin'
      };
      
      setAdminUser(mockAdminUser);
      localStorage.setItem('adminUser', JSON.stringify(mockAdminUser));
    } else {
      throw new Error('Invalid credentials');
    }
    
    setIsLoading(false);
  };

  const logout = () => {
    setAdminUser(null);
    localStorage.removeItem('adminUser');
  };

  // Check for existing session on mount
  React.useEffect(() => {
    const savedAdminUser = localStorage.getItem('adminUser');
    if (savedAdminUser) {
      setAdminUser(JSON.parse(savedAdminUser));
    }
  }, []);

  return (
    <AdminContext.Provider value={{ adminUser, login, logout, isLoading }}>
      {children}
    </AdminContext.Provider>
  );
};